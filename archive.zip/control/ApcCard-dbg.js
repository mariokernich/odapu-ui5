sap.ui.define(["sap/f/Card", "sap/f/cards/Header", "sap/m/Button", "sap/m/Column", "sap/m/ColumnListItem", "sap/m/HBox", "sap/m/Input", "sap/m/MessageToast", "sap/m/Table", "sap/m/Text", "sap/m/VBox", "sap/ui/core/Renderer", "sap/ui/core/ws/SapPcpWebSocket", "sap/ui/model/json/JSONModel", "../util/DialogManager"], function (Card, Header, Button, Column, ColumnListItem, HBox, Input, MessageToast, Table, Text, VBox, Renderer, SapPcpWebSocket, JSONModel, __DialogManager) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const DialogManager = _interopRequireDefault(__DialogManager);
  /**
   * @namespace de.kernich.odpu.control
   */
  const ApcCard = Card.extend("de.kernich.odpu.control.ApcCard", {
    renderer: Renderer.extend(Card),
    metadata: {
      properties: {
        path: {
          type: "string",
          defaultValue: ""
        },
        applicationId: {
          type: "string",
          defaultValue: ""
        }
      },
      events: {
        delete: {}
      }
    },
    constructor: function _constructor(id, settings) {
      Card.prototype.constructor.call(this, id, settings);
      this.apcData = {
        applicationId: "",
        path: "",
        running: false,
        busy: false
      };
      this.setModel(new JSONModel(this.apcData, true), "control");
      const header = new Header({
        title: "{control>/applicationId}",
        subtitle: "{control>/path}"
      });
      this.setHeader(header);
      const container = new VBox();
      this.setBusyIndicatorDelay(0);
      container.addStyleClass("sapUiSmallMargin");
      this.table = new Table();
      this.table.addColumn(new Column({
        header: new Text({
          text: "Event"
        }),
        width: "80px"
      }));
      this.table.addColumn(new Column({
        header: new Text({
          text: "Data"
        })
      }));
      this.table.addColumn(new Column({
        header: new Text({
          text: "Time"
        }),
        width: "80px"
      }));
      const submitMessage = () => {
        this.sendMessage(messageInput.getValue());
        messageInput.setValue("");
      };
      const messageInput = new Input({
        placeholder: "Enter message...",
        enabled: "{control>/running}",
        width: "100%",
        submit: submitMessage
      });
      const clearTable = async () => {
        const confirmed = await DialogManager.showConfirmationDialog("Are you sure you want to clear the table?");
        if (confirmed) {
          this.table.destroyItems();
        }
      };
      const stop = async () => {
        const confirmed = await DialogManager.showConfirmationDialog("Are you sure you want to stop the connection?");
        if (confirmed) {
          void this.stop();
        }
      };
      const subHeader = new HBox({
        justifyContent: "SpaceBetween",
        alignItems: "Center",
        items: [new Text({
          text: "Connected: {control>/running}"
        }), new HBox({
          items: [new Button({
            tooltip: "Connect",
            icon: "sap-icon://connected",
            visible: "{= ${control>/running} === false}",
            press: () => {
              void this.start();
            }
          }), new Button({
            tooltip: "Disconnect",
            icon: "sap-icon://disconnected",
            visible: "{= ${control>/running} === true}",
            press: () => {
              void stop();
            }
          }), new Button({
            tooltip: "Clear",
            icon: "sap-icon://clear-all",
            press: () => {
              void clearTable();
            }
          }).addStyleClass("sapUiTinyMarginBegin"), new Button({
            type: "Reject",
            icon: "sap-icon://delete",
            press: () => {
              this.fireDelete();
            }
          }).addStyleClass("sapUiTinyMarginBegin")]
        })]
      });
      container.addItem(subHeader);
      container.addItem(this.table);
      const menu = new HBox({
        renderType: "Bare",
        items: [messageInput, new Button({
          text: "Send",
          enabled: "{control>/running}",
          press: submitMessage
        }).addStyleClass("sapUiSmallMarginBegin")]
      });
      container.addItem(menu);
      this.setContent(container);
    },
    start: async function _start() {
      this.setBusy(true);
      try {
        this.socket = new SapPcpWebSocket(this.apcData.path);
        this.socket.attachMessage(message => {
          const body = message.getParameters().data;
          let text;
          if (typeof body === "string") {
            text = body;
          } else {
            text = JSON.stringify(body);
          }

          //const pcp = message.getParameters().pcpFields;
          this.table.addItem(new ColumnListItem({
            cells: [new Text({
              text: "Receiving"
            }), new Text({
              text: text
            }), new Text({
              text: new Date().toLocaleTimeString()
            })]
          }));
        });
        await new Promise((resolve, reject) => {
          this.socket.attachOpen(() => {
            this.setBusy(false);
            this.apcData.running = true;
            MessageToast.show("connected: " + this.apcData.path);
            console.log("connected: " + this.apcData.path);
            resolve();
          });
          this.socket.attachError(error => {
            MessageToast.show("error: " + JSON.stringify(error));
            console.log("error at " + this.apcData.path + ": " + JSON.stringify(error));
            reject(new Error("failed to connect: " + JSON.stringify(error)));
          });
        });
      } finally {
        this.setBusy(false);
      }
    },
    stop: function _stop() {
      this.setBusy(true);
      this.socket?.close();
      this.socket.attachClose(() => {
        this.setBusy(false);
        this.apcData.running = false;
        MessageToast.show("disconnected");
      });
    },
    sendMessage: function _sendMessage(message) {
      this.socket?.send(message);
      this.table.addItem(new ColumnListItem({
        cells: [new Text({
          text: "Sending"
        }), new Text({
          text: message
        }), new Text({
          text: new Date().toLocaleTimeString()
        })]
      }));
    },
    setPath: function _setPath(path) {
      this.setProperty("path", path);
      this.apcData.path = path;
    },
    setApplicationId: function _setApplicationId(applicationId) {
      this.setProperty("applicationId", applicationId);
      this.apcData.applicationId = applicationId;
    }
  });
  return ApcCard;
});
//# sourceMappingURL=ApcCard-dbg.js.map
