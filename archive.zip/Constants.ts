export default class Constants {
	public static readonly SERVICE_QUERY_LIMIT = 2000;
}
