sap.ui.define([], function () {
  "use strict";

  /**
   * Formatter for the OData Client application
   */
  var __exports = {
    /**
     * Formats a JSON string with proper indentation
     * @param sValue - The JSON string or object to format
     * @returns The formatted JSON string
     */
    formatJSON(sValue) {
      if (!sValue) {
        return "";
      }
      try {
        // If the value is already a string, parse it first
        const jsonObj = typeof sValue === "string" ? JSON.parse(sValue) : sValue;
        // Format with 4 spaces indentation
        return JSON.stringify(jsonObj, null, 4);
      } catch {
        // If parsing fails, return the original value
        return typeof sValue === "string" ? sValue : JSON.stringify(sValue);
      }
    }
  };
  return __exports;
});
//# sourceMappingURL=formatter-dbg.js.map
