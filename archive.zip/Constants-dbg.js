sap.ui.define([], function () {
  "use strict";

  class Constants {
    static SERVICE_QUERY_LIMIT = 2000;
  }
  return Constants;
});
//# sourceMappingURL=Constants-dbg.js.map
