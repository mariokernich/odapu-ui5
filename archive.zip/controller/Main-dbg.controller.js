sap.ui.define(["./BaseController", "../util/DialogManager", "sap/m/TabContainerItem", "sap/ui/core/Fragment", "./OData.controller", "sap/m/VBox", "./APC.controller", "sap/ui/model/json/JSONModel"], function (__BaseController, __DialogManager, TabContainerItem, Fragment, __OData, VBox, __APC, JSONModel) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const DialogManager = _interopRequireDefault(__DialogManager);
  const OData = _interopRequireDefault(__OData);
  const APC = _interopRequireDefault(__APC);
  /**
   * @namespace de.kernich.odpu.controller
   */
  const Main = BaseController.extend("de.kernich.odpu.controller.Main", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.local = {
        githubIcon: sap.ui.require.toUrl("de/kernich/odpu/img/github-brands.svg"),
        linkedinIcon: sap.ui.require.toUrl("de/kernich/odpu/img/linkedin-brands.svg")
      };
    },
    onTabContainerAddNewButtonPress: function _onTabContainerAddNewButtonPress() {
      void this.handleAddNewButtonPress();
    },
    onTabContainerItemClose: function _onTabContainerItemClose() {},
    onInit: function _onInit() {
      BaseController.prototype.onInit.call(this);
      void this.handleInit();
      this.getView().setModel(new JSONModel(this.local), "local");
    },
    handleInit: async function _handleInit() {
      const tabContainer = this.getTabContainer();
      const item = new TabContainerItem({
        name: "Untitled",
        additionalText: "ODATA",
        modified: false
      });
      const id = "__" + new Date().getTime().toString();
      const controller = new OData(id);
      controller.component = this.getOwnerComponent();
      controller.getOwnerComponent = () => this.getOwnerComponent();
      controller.fragmentId = id;
      const fragment = await Fragment.load({
        name: "de.kernich.odpu.view.fragments.ODATA.Main",
        controller: controller,
        id: id
      });
      controller.getView = () => fragment;
      item.addContent(new VBox({
        items: fragment,
        renderType: "Bare",
        fitContainer: true,
        height: "100%"
      }));
      tabContainer.addItem(item);
      controller.onInit();
      controller.setTitle = title => {
        item.setName(title);
      };
      this.setSelectedItem(item);
    },
    setSelectedItem: function _setSelectedItem(item) {
      while (this.getTabContainer().getSelectedItem() !== item.getId()) {
        this.getTabContainer().setSelectedItem(item);
      }
    },
    handleAddNewButtonPress: async function _handleAddNewButtonPress() {
      const projectType = await DialogManager.selectProjectType();
      console.log(projectType);
      const tabContainer = this.getTabContainer();
      const item = new TabContainerItem({
        name: "Untitled",
        additionalText: projectType,
        modified: false
      });
      const id = "__" + new Date().getTime().toString();
      if (projectType === "ODATA") {
        const controller = new OData(id);
        controller.component = this.getOwnerComponent();
        controller.getOwnerComponent = () => this.getOwnerComponent();
        controller.fragmentId = id;
        const fragment = await Fragment.load({
          name: "de.kernich.odpu.view.fragments.ODATA.Main",
          controller: controller,
          id: id
        });
        controller.getView = () => fragment;
        item.addContent(new VBox({
          items: fragment,
          renderType: "Bare",
          fitContainer: true,
          height: "100%"
        }));
        tabContainer.addItem(item);
        controller.onInit();
        controller.setTitle = title => {
          item.setName(title);
        };
        tabContainer.setSelectedItem(item);
      }
      if (projectType === "APC") {
        const controller = new APC(id);
        controller.component = this.getOwnerComponent();
        controller.getOwnerComponent = () => this.getOwnerComponent();
        controller.fragmentId = id;
        const fragment = await Fragment.load({
          name: "de.kernich.odpu.view.fragments.APC.Main",
          controller: controller,
          id: id
        });
        tabContainer.addItem(item);
        controller.getView = () => fragment;
        controller.onInit();
        item.addContent(new VBox({
          items: fragment,
          renderType: "Bare",
          fitContainer: true,
          height: "100%"
        }));
        controller.setTitle = title => {
          item.setName(title);
        };
        this.setSelectedItem(item);
      }
    },
    getTabContainer: function _getTabContainer() {
      return this.getView().byId("idTabContainer");
    }
  });
  return Main;
});
//# sourceMappingURL=Main-dbg.controller.js.map
