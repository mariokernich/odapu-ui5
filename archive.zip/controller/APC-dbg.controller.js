sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageToast", "../Constants", "sap/ui/Device", "sap/ui/core/Core", "sap/ui/core/ws/SapPcpWebSocket", "../util/Util"], function (__BaseController, JSONModel, MessageToast, __Constants, Device, Core, SapPcpWebSocket, __Util) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const Constants = _interopRequireDefault(__Constants);
  const Util = _interopRequireDefault(__Util);
  /**
   * @namespace de.kernich.odpu.controller
   */
  const APC = BaseController.extend("de.kernich.odpu.controller.APC", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.local = {
        folderTreeIcon: sap.ui.require.toUrl("de/kernich/odpu/img/folder-tree-light.svg")
      };
      this.fragmentId = "";
      this.apcModel = {
        selectedApc: {
          path: ""
        },
        state: "disconnected"
      };
      this.apcLog = {
        entries: []
      };
      this.apcView = {
        githubIcon: sap.ui.require.toUrl("de/kernich/odpu/img/github-brands.svg"),
        linkedinIcon: sap.ui.require.toUrl("de/kernich/odpu/img/linkedin-brands.svg")
      };
    },
    onInit: function _onInit() {
      BaseController.prototype.onInit.call(this);
      void this.handleInit();
      this.getView().setModel(new JSONModel(this.apcModel, true), "apcModel");
      this.getView().setModel(new JSONModel(this.apcLog, true), "apcLog");
      this.getView().setModel(new JSONModel(this.apcView, true), "apcView");
    },
    handleInit: async function _handleInit() {
      await this.getGlobalModel().dataLoaded();
      this.setBusy(true);
      await this.initModel();
      this.setBusy(false);
      if (!Device.support.websocket) {
        MessageToast.show("Note: WebSocket not supported");
      }
    },
    onChoosePushChannelButtonPress: function _onChoosePushChannelButtonPress() {
      void this.handleAddApc();
    },
    onDisconnectPushChannelButtonPress: function _onDisconnectPushChannelButtonPress() {
      this.socket?.close();
      this.apcModel.state = "disconnected";
      MessageToast.show("Disconnected from " + this.apcModel.selectedApc.path);
      this.apcModel.selectedApc = {
        path: ""
      };
    },
    onClearPushChannelButtonPress: function _onClearPushChannelButtonPress() {
      this.apcLog.entries = [];
      this.refreshApcLog();
    },
    handleAddApc: async function _handleAddApc() {
      this.setBusy(true);
      try {
        const apcList = await this.getApc();
        const selectedApc = await this.component.dialogManager.pickApc(apcList);
        this.apcModel.selectedApc = selectedApc;
        this.setTitle(selectedApc.application_id);
      } finally {
        this.setBusy(false);
      }
    },
    initModel: async function _initModel() {
      const model = this.getOwnerComponent().getModel();
      await model.metadataLoaded(true);
      model.setSizeLimit(Constants.SERVICE_QUERY_LIMIT);
    },
    onConnectPushChannelButtonPress: async function _onConnectPushChannelButtonPress() {
      this.setBusy(true);
      try {
        await new Promise((resolve, reject) => {
          this.socket = new SapPcpWebSocket(this.apcModel.selectedApc.path);
          this.socket.attachMessage(event => {
            this.apcLog.entries.push({
              participant: "Server",
              data: event.getParameters().data,
              timestamp: new Date().toISOString()
            });
            this.refreshApcLog();
          });
          this.socket.attachOpen(() => {
            this.apcModel.state = "connected";
            resolve();
          });
          this.socket.attachClose(() => {
            this.apcModel.state = "disconnected";
          });
          this.socket.attachError(error => {
            reject(new Error("failed to connect: " + JSON.stringify(error)));
          });
        });
        this.focusFeedInput();
        MessageToast.show("Connected to " + this.apcModel.selectedApc.path);
      } catch (error) {
        Util.showError(error);
      } finally {
        this.setBusy(false);
      }
    },
    getApc: async function _getApc() {
      const model = this.getOwnerComponent().getModel();
      return new Promise((resolve, reject) => {
        model.read("/apcSet", {
          success: data => {
            resolve(data.results);
          },
          error: reject,
          urlParameters: {
            $top: Constants.SERVICE_QUERY_LIMIT.toString()
          }
        });
      });
    },
    getById: function _getById(id) {
      const fragmentId = this.fragmentId;
      const globalId = `${fragmentId}--${id}`;
      const control = Core.byId(globalId);
      return control;
    },
    refreshApcLog: function _refreshApcLog() {
      this.getView().getModel("apcLog").refresh();
      this.getById("idLogTable").refreshAggregation("items");
    },
    onPostMessageButtonPress: function _onPostMessageButtonPress(event) {
      this.apcLog.entries.push({
        participant: "Client",
        data: event.getParameters().value,
        timestamp: new Date().toISOString()
      });
      this.socket?.send(event.getParameters().value);
      this.refreshApcLog();
      this.focusFeedInput();
    },
    focusFeedInput: function _focusFeedInput() {
      this.getById("idFeedInput")?.focus();
    },
    setTitle: function _setTitle(title) {
      throw new Error("Not implemented");
    }
  });
  return APC;
});
//# sourceMappingURL=APC-dbg.controller.js.map
