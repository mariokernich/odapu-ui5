sap.ui.define(["sap/m/DatePicker", "sap/m/DateTimePicker", "sap/m/Input", "sap/m/MessageBox", "sap/m/StepInput", "sap/m/Switch", "sap/m/TimePicker", "sap/ui/base/ManagedObject", "sap/ui/core/Control"], function (DatePicker, DateTimePicker, Input, MessageBox, StepInput, Switch, TimePicker, ManagedObject, Control) {
  "use strict";

  /**
   * @namespace de.kernich.odpu.util
   */
  const Util = ManagedObject.extend("de.kernich.odpu.util.Util", {});
  Util.copy2Clipboard = async function copy2Clipboard(text) {
    await navigator.clipboard.writeText(text);
  };
  Util.openUrl = function openUrl(url) {
    window.open(url, "_blank");
  };
  Util.showError = function showError(error) {
    if (typeof error === "string") {
      MessageBox.error(error);
    } else if (error instanceof Error) {
      MessageBox.error(error.toString());
    } else {
      MessageBox.error(JSON.stringify(error));
    }
  };
  Util.getErrorMessage = function getErrorMessage(error) {
    if (typeof error === "string") {
      return error;
    } else if (error instanceof Error) {
      return error.toString();
    }
    return JSON.stringify(error);
  };
  Util.formatXml = function formatXml(xml) {
    let formatted = "";
    let indent = "";
    const tab = "    "; // 4 spaces for indentation
    xml.split(/>\s*</).forEach(node => {
      if (node.match(/^\/\w/)) {
        // Closing tag
        indent = indent.substring(tab.length);
      }
      formatted += indent + "<" + node + ">\r\n";
      if (node.match(/^<?\w[^>]*[^\/]$/) && !node.startsWith("?")) {
        // Opening tag
        indent += tab;
      }
    });
    return formatted.substring(1, formatted.length - 3);
  };
  Util.resetInputs = function resetInputs(control) {
    if ((control instanceof Input || control instanceof Switch || control instanceof StepInput || control instanceof DatePicker || control instanceof TimePicker || control instanceof DateTimePicker) && control.getVisible() === true) {
      if (control instanceof Switch) {
        control.setState(false);
      } else {
        control.setValue("");
      }
    }
    if (control instanceof Control) {
      const items = control.getAggregation("items");
      if (items) {
        items.forEach(item => {
          Util.resetInputs(item);
        });
      }
    }
  };
  Util.getAllInputValues = function getAllInputValues(control) {
    let values = {};
    if ((control instanceof Input || control instanceof Switch || control instanceof StepInput || control instanceof DatePicker || control instanceof TimePicker || control instanceof DateTimePicker) && control.getVisible() === true) {
      if (control instanceof Switch) {
        values[control.getName()] = control.getEnabled();
      } else {
        values[control.getName()] = control.getValue();
      }
    }
    if (control instanceof Control) {
      const items = control.getAggregation("items");
      if (items) {
        items.forEach(item => {
          values = {
            ...values,
            ...Util.getAllInputValues(item)
          };
        });
      }
    }
    return values;
  };
  return Util;
});
//# sourceMappingURL=Util-dbg.js.map
