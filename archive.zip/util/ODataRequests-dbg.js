sap.ui.define(["sap/ui/base/ManagedObject", "../Constants"], function (ManagedObject, __Constants) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const Constants = _interopRequireDefault(__Constants);
  /**
   * @namespace de.kernich.odpu.util
   */
  const ODataRequests = ManagedObject.extend("de.kernich.odpu.util.ODataRequests", {
    constructor: function _constructor(model) {
      ManagedObject.prototype.constructor.call(this);
      this.model = model;
    },
    getModel: function _getModel() {
      return this.model;
    },
    getServices: async function _getServices() {
      return new Promise((resolve, reject) => {
        this.model.read("/serviceSet", {
          success: data => {
            resolve(data.results);
          },
          error: reject,
          urlParameters: {
            $top: Constants.SERVICE_QUERY_LIMIT.toString()
          }
        });
      });
    },
    getProjects: async function _getProjects() {
      return new Promise((resolve, reject) => {
        this.model.read("/odataProjectSet", {
          success: data => {
            resolve(data.results);
          },
          error: reject
        });
      });
    },
    createProject: async function _createProject(project) {
      return new Promise((resolve, reject) => {
        this.model.create("/odataProjectSet", project, {
          success: () => resolve(),
          error: reject
        });
      });
    },
    deleteProject: async function _deleteProject(project) {
      return new Promise((resolve, reject) => {
        const sPath = this.model.createKey("/odataProjectSet", {
          ProjectName: project.ProjectName
        });
        this.model.remove(sPath, {
          success: () => resolve(),
          error: reject
        });
      });
    }
  });
  return ODataRequests;
});
//# sourceMappingURL=ODataRequests-dbg.js.map
