sap.ui.define(["sap/ui/model/odata/v2/ODataModel", "./ODataHelper", "sap/m/MessageBox", "./Util"], function (ODataModelV2, __ODataHelper, MessageBox, __Util) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ODataHelper = _interopRequireDefault(__ODataHelper);
  const Util = _interopRequireDefault(__Util);
  /**
   * @namespace de.kernich.odpu.util
   */
  class OData2Client {
    constructor(serviceUrl) {
      this.serviceUrl = serviceUrl;
      this.model = new ODataModelV2(serviceUrl, {});
      this.model.attachRequestFailed({}, event => {
        const parameters = event.getParameters();
        const responseText = parameters.response.responseText;
        if (responseText.startsWith("<?xml")) {
          // Handle XML response
          const parser = new DOMParser();
          const xmlDoc = parser.parseFromString(responseText, "text/xml");
          const messageNode = xmlDoc.getElementsByTagName("message")[0];
          if (messageNode) {
            MessageBox.error(messageNode.textContent);
          } else {
            MessageBox.error("Unknown error occurred");
          }
        } else {
          // Handle JSON response
          const json = JSON.parse(responseText);
          MessageBox.error(json.error.message.value);
        }
      });
    }
    getActions() {
      return [];
    }
    destroy() {}
    async createEntity(entityName, properties) {
      await new Promise((resolve, reject) => {
        this.model.create(`/${entityName}`, properties, {
          success: () => resolve(),
          error: error => reject(error)
        });
      });
    }
    async getEntity(entityName, keys) {
      const path = this.model.createKey(`/${entityName}`, keys);
      const context = await new Promise((resolve, reject) => {
        this.model.createBindingContext(path, undefined, {}, data => {
          if (data) {
            resolve(data);
          } else {
            reject(new Error("Failed to create binding context"));
          }
        }, true);
      });
      return context.getObject();
    }
    async deleteEntity(entityName, keys) {
      const path = this.model.createKey(`/${entityName}`, keys);
      await new Promise((resolve, reject) => {
        this.model.remove(path, {
          success: () => resolve(),
          error: error => reject(error)
        });
      });
    }
    async initAsync() {
      try {
        await this.model.metadataLoaded(true);
      } catch (error) {
        MessageBox.error("Failed to load metadata of Service " + this.serviceUrl + ":\n\nPlease check Backend configuration and try again.", {
          details: Util.getErrorMessage(error)
        });
        throw error;
      }
      this.metadataText = await ODataHelper.getMetadataText(this.serviceUrl);
      this.metadataXml = ODataHelper.parseMetadataXml(this.metadataText);
    }
    getEntities() {
      const entities = [];
      const entitySets = Array.from(this.metadataXml.getElementsByTagName("EntitySet")).map(node => ({
        Name: node.getAttribute("Name"),
        EntityType: node.getAttribute("EntityType")
      }));
      for (const entity of entitySets) {
        let entityType = entity.EntityType;
        if (entityType.includes(".")) {
          entityType = entityType.split(".").pop();
        }
        const entityTypeNode = Array.from(this.metadataXml.getElementsByTagName("EntityType")).find(node => {
          return node.getAttribute("Name") === entityType;
        });
        const properties = Array.from(entityTypeNode.getElementsByTagName("Property")).map(propertyNode => ({
          name: propertyNode.getAttribute("Name"),
          type: propertyNode.getAttribute("Type"),
          nullable: propertyNode.getAttribute("Nullable"),
          maxLength: ODataHelper.getMaxLength(propertyNode.getAttribute("MaxLength"))
        }));
        const keyNode = entityTypeNode.getElementsByTagName("Key")[0];
        const propertyRefs = Array.from(keyNode.getElementsByTagName("PropertyRef")).map(keyNode => ({
          name: keyNode.getAttribute("Name"),
          type: properties.find(property => property.name === keyNode.getAttribute("Name")).type,
          nullable: properties.find(property => property.name === keyNode.getAttribute("Name")).nullable,
          maxLength: properties.find(property => property.name === keyNode.getAttribute("Name")).maxLength
        }));
        entities.push({
          name: entity.Name,
          entityType: entityType,
          properties: properties,
          keys: propertyRefs
        });
      }
      return entities.filter(entity => !entity.name.startsWith("SAP__"));
    }
    getMetadataText() {
      return this.metadataText;
    }
    getMetadataXml() {
      return this.metadataXml;
    }
    getFunctions() {
      const functionImports = Array.from(this.metadataXml.getElementsByTagName("FunctionImport")).map(node => ({
        Name: node.getAttribute("Name"),
        ReturnType: node.getAttribute("ReturnType"),
        EntitySet: node.getAttribute("EntitySet"),
        HttpMethod: node.getAttribute("m:HttpMethod"),
        Parameters: Array.from(node.getElementsByTagName("Parameter")).map(paramNode => ({
          name: paramNode.getAttribute("Name"),
          type: paramNode.getAttribute("Type"),
          nullable: paramNode.getAttribute("Nullable"),
          maxLength: ODataHelper.getMaxLength(paramNode.getAttribute("MaxLength"))
        }))
      }));
      return functionImports.map(func => ({
        name: func.Name,
        returnType: func.ReturnType,
        entitySet: func.EntitySet,
        parameters: func.Parameters,
        method: func.HttpMethod
      }));
    }
    getModel() {
      return this.model;
    }
    async readEntity(options) {
      this.model.setHeaders(options.headers);
      return await new Promise((resolve, reject) => {
        this.model.read(`/${options.entityName}`, {
          success: data => {
            resolve(data);
          },
          error: error => {
            reject(error);
          },
          filters: options.filters.length > 0 ? options.filters : undefined,
          sorters: options.sorting.length > 0 ? options.sorting : undefined,
          urlParameters: {
            $top: options.top.toString(),
            $skip: options.skip.toString()
          }
        });
      });
    }
    async executeFunction(options) {
      return await new Promise((resolve, reject) => {
        this.model.callFunction(`/${options.functionName}`, {
          urlParameters: options.parameters,
          method: options.method,
          success: data => resolve(data),
          error: error => reject(error)
        });
      });
    }
    executeAction(options) {
      throw new Error("Not implemented");
    }
  }
  return OData2Client;
});
//# sourceMappingURL=OData2Client-dbg.js.map
