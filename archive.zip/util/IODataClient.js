sap.ui.define([],function(){"use strict";return IODataClient});
//# sourceMappingURL=IODataClient.js.map