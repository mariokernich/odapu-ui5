sap.ui.define(["sap/ui/base/ManagedObject"], function (ManagedObject) {
  "use strict";

  /**
   * @namespace de.kernich.odpu.util
   */
  const ODataHelper = ManagedObject.extend("de.kernich.odpu.util.ODataHelper", {});
  ODataHelper.getMetadataText = async function getMetadataText(servicePath) {
    let escaped = servicePath;
    while (escaped.endsWith("/")) {
      escaped = escaped.slice(0, -1);
    }
    const metadata = await fetch(escaped + "/$metadata", {
      headers: {
        "Content-Type": "application/json"
      }
    });
    return await metadata.text();
  };
  ODataHelper.getMetadataXml = async function getMetadataXml(servicePath) {
    const metadata = await this.getMetadataText(servicePath);
    const parser = new DOMParser();
    return parser.parseFromString(metadata, "application/xml");
  };
  ODataHelper.parseMetadataXml = function parseMetadataXml(contents) {
    const parser = new DOMParser();
    return parser.parseFromString(contents, "application/xml");
  };
  ODataHelper.getMaxLength = function getMaxLength(value) {
    try {
      const parsed = Number.parseInt(value, 10);
      if (!isNaN(parsed)) {
        return parsed;
      }
    } catch (error) {
      // Handle parsing error
      console.error("Parsing error:", error);
    }
    return 0;
  };
  return ODataHelper;
});
//# sourceMappingURL=ODataHelper-dbg.js.map
