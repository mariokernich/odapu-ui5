sap.ui.define(["sap/ui/model/odata/v4/ODataModel", "./ODataHelper", "sap/m/MessageBox"], function (ODataModelV4, __ODataHelper, MessageBox) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ODataHelper = _interopRequireDefault(__ODataHelper);
  /**
   * @namespace de.kernich.odpu.util
   */
  class OData4Client {
    constructor(serviceUrl) {
      let escapedServiceUrl = serviceUrl;
      if (!escapedServiceUrl.endsWith("/")) {
        escapedServiceUrl += "/";
      }
      this.serviceUrl = escapedServiceUrl;
      this.model = new ODataModelV4({
        serviceUrl: escapedServiceUrl,
        synchronizationMode: "None",
        earlyRequests: true,
        httpHeaders: {}
      });
      this.model.attachDataReceived({}, event => {
        const parameters = event.getParameters();
        if (parameters.error?.status >= 400) {
          const message = "Requested failed: " + parameters.error.requestUrl + "\n\nMessage: " + parameters.error.message;
          MessageBox.error(message);
        }
      });
    }
    getActions() {
      const actions = [];
      const actionNodes = Array.from(this.metadataXml.getElementsByTagName("Action")).map(node => ({
        Name: node.getAttribute("Name"),
        IsBound: node.getAttribute("IsBound"),
        Parameters: Array.from(node.getElementsByTagName("Parameter")).map(paramNode => ({
          Name: paramNode.getAttribute("Name"),
          Type: paramNode.getAttribute("Type"),
          Nullable: paramNode.getAttribute("Nullable")
        }))
      }));
      for (const action of actionNodes) {
        actions.push({
          name: action.Name,
          isBound: action.IsBound === "true",
          parameters: action.Parameters.map(param => ({
            name: param.Name,
            type: param.Type,
            nullable: param.Nullable === "true"
          }))
        });
      }
      return actions;
    }
    destroy() {}
    async createEntity(entityName, properties) {
      const binding = this.model.bindList(`/${entityName}`, undefined, [], [], {
        $$getKeepAliveContext: true
      });
      const createdContext = binding.create(properties);
      await createdContext.created();
    }
    deleteEntity(entityName, keys) {
      const keyPath = Object.entries(keys).map(_ref => {
        let [key, value] = _ref;
        return `${key}='${value}'`;
      }).join(",");
      const entityBinding = this.model.getKeepAliveContext(`/${entityName}(${keyPath})`);
      return entityBinding.delete();
    }
    async getEntity(entityName, keys) {
      const keyPath = Object.entries(keys).map(_ref2 => {
        let [key, value] = _ref2;
        return `${key}='${value}'`;
      }).join(",");
      const binding = this.model.bindContext(`/${entityName}(${keyPath})`);
      const obj = await binding.requestObject();
      if (obj === undefined) {
        throw new Error("Entity not found");
      }
      return obj;
    }
    getEntities() {
      const entities = [];
      const entitySets = Array.from(this.metadataXml.getElementsByTagName("EntitySet")).map(node => ({
        Name: node.getAttribute("Name"),
        EntityType: node.getAttribute("EntityType")
      }));
      for (const entity of entitySets) {
        let entityType = entity.EntityType;
        if (entityType.includes(".")) {
          entityType = entityType.split(".").pop();
        }
        const entityTypeNode = Array.from(this.metadataXml.getElementsByTagName("EntityType")).find(node => {
          return node.getAttribute("Name") === entityType;
        });
        const properties = Array.from(entityTypeNode.getElementsByTagName("Property")).map(propertyNode => ({
          name: propertyNode.getAttribute("Name"),
          type: propertyNode.getAttribute("Type"),
          nullable: propertyNode.getAttribute("Nullable"),
          maxLength: ODataHelper.getMaxLength(propertyNode.getAttribute("MaxLength"))
        }));
        const keyNode = entityTypeNode.getElementsByTagName("Key")[0];
        const propertyRefs = Array.from(keyNode.getElementsByTagName("PropertyRef")).map(keyNode => ({
          name: keyNode.getAttribute("Name"),
          type: properties.find(property => property.name === keyNode.getAttribute("Name")).type,
          nullable: properties.find(property => property.name === keyNode.getAttribute("Name")).nullable,
          maxLength: properties.find(property => property.name === keyNode.getAttribute("Name")).maxLength
        }));
        entities.push({
          name: entity.Name,
          entityType: entityType,
          properties: properties,
          keys: propertyRefs
        });
      }
      return entities;
    }
    getFunctions() {
      const functionImports = Array.from(this.metadataXml.getElementsByTagName("FunctionImport")).map(node => ({
        Name: node.getAttribute("Name"),
        ReturnType: node.getAttribute("ReturnType"),
        EntitySet: node.getAttribute("EntitySet"),
        HttpMethod: node.getAttribute("m:HttpMethod")
      }));
      return functionImports.map(func => {
        const parameters = Array.from(this.metadataXml.getElementsByTagName("Parameter")).map(paramNode => ({
          name: paramNode.getAttribute("Name"),
          type: paramNode.getAttribute("Type"),
          nullable: paramNode.getAttribute("Nullable"),
          maxLength: ODataHelper.getMaxLength(paramNode.getAttribute("MaxLength"))
        }));
        return {
          name: func.Name,
          returnType: func.ReturnType,
          entitySet: func.EntitySet,
          parameters: parameters,
          method: func.HttpMethod
        };
      });
    }
    async readEntity(options) {
      const binding = this.model.bindList("/" + options.entityName, undefined, [], [], {});
      const contexts = await binding.requestContexts();
      return contexts.map(context => context.getObject());
    }
    getModel() {
      return this.model;
    }
    getMetadataText() {
      return this.metadataText;
    }
    getMetadataXml() {
      return this.metadataXml;
    }
    async initAsync() {
      this.metadataText = await ODataHelper.getMetadataText(this.serviceUrl);
      this.metadataXml = ODataHelper.parseMetadataXml(this.metadataText);
    }
    executeFunction(options) {
      throw new Error("Not implemented");
    }
    executeAction(options) {
      throw new Error("Not implemented");
    }
  }
  return OData4Client;
});
//# sourceMappingURL=OData4Client-dbg.js.map
