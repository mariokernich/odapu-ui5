sap.ui.define(["sap/ui/core/UIComponent", "./util/DialogManager", "./util/ODataRequests", "sap/ui/Device", "sap/ui/model/json/JSONModel", "sap/m/MessageBox"], function (UIComponent, __DialogManager, __ODataRequests, Device, JSONModel, MessageBox) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const DialogManager = _interopRequireDefault(__DialogManager);
  const ODataRequests = _interopRequireDefault(__ODataRequests);
  /**
   * @namespace de.kernich.odpu
   */
  const Component = UIComponent.extend("de.kernich.odpu.Component", {
    metadata: {
      manifest: "json"
    },
    init: function _init() {
      UIComponent.prototype.init.call(this);
      this.setModel(new JSONModel(Device), "device");
      this.dialogManager = new DialogManager(this);
      this.model = this.getModel();
      this.requests = new ODataRequests(this.model);
      this.model.attachRequestFailed({}, event => {
        const parameters = event.getParameters();
        const responseText = parameters.response.responseText;
        if (responseText.startsWith("<?xml")) {
          // Handle XML response
          const parser = new DOMParser();
          const xmlDoc = parser.parseFromString(responseText, "text/xml");
          const messageNode = xmlDoc.getElementsByTagName("message")[0];
          if (messageNode) {
            MessageBox.error(messageNode.textContent);
          } else {
            MessageBox.error("Unknown error occurred");
          }
        } else {
          // Handle JSON response
          const json = JSON.parse(responseText);
          MessageBox.error(json.error.message.value);
        }
      });
      this.getRouter().initialize();
    },
    /**
     * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
     * design mode class should be set, which influences the size appearance of some controls.
     * @public
     * @returns css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
     */
    getContentDensityClass: function _getContentDensityClass() {
      if (this.contentDensityClass === undefined) {
        // check whether FLP has already set the content density class; do nothing in this case
        if (document.body.classList.contains("sapUiSizeCozy") || document.body.classList.contains("sapUiSizeCompact")) {
          this.contentDensityClass = "";
        } else if (!Device.support.touch) {
          // apply "compact" mode if touch is not supported
          this.contentDensityClass = "sapUiSizeCompact";
        } else {
          // "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
          this.contentDensityClass = "sapUiSizeCozy";
        }
      }
      return this.contentDensityClass;
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
